package com.example.pr2xavierroca

import com.example.pr2xavierroca.BD.Capitol
import com.example.pr2xavierroca.BD.Serie


var listSeries: java.util.ArrayList<Serie> = arrayListOf()
var listCapitols: java.util.ArrayList<Capitol> = arrayListOf()

