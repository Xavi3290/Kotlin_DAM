package com.example.activitat5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.activitat5.databinding.ActivityMain3Binding
import com.example.activitat5.databinding.ActivityMainBinding

class MainActivity3 : AppCompatActivity() {
    private lateinit var binding: ActivityMain3Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMain3Binding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val actionBar = supportActionBar
        actionBar!!.title = "Tercera Activity"
        actionBar.setDisplayHomeAsUpEnabled(true)  // flecha de tornar
        finish()
    }
}