package com.example.activitat9bona

class Producte_Json : ArrayList<Producte_JsonItem>()