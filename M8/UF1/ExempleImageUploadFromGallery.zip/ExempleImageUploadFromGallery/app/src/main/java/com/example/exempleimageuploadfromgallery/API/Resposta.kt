package com.example.exempleimageuploadfromgallery.API

data class UploadResponse(
    val error: Boolean,
    val image: String
)

val urlapi = "http://172.16.24.50/"
