package com.example.retrofit1

data class Dada(
    val `data`: List<Data>,
    val message: String,
    val status: String
)