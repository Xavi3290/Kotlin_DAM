package com.example.retrofit1

data class DataX(
    val age: String,
    val id: Int,
    val name: String,
    val salary: String
)