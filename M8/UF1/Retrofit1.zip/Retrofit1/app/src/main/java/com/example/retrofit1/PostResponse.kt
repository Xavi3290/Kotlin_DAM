package com.example.retrofit1

data class PostResponse(
    val `data`: DataX,
    val status: String
)